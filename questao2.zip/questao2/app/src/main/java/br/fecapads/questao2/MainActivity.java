package br.fecapads.questao2;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editSalario;
    RadioGroup radioGroup;
    Button btnCalcular;
    TextView textResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editSalario = findViewById(R.id.editSalario);
        radioGroup = findViewById(R.id.radioGroup);
        btnCalcular = findViewById(R.id.btnCalcular);
        textResultado = findViewById(R.id.textResultado);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String salarioStr = editSalario.getText().toString();
                if (salarioStr.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Digite o salário!", Toast.LENGTH_SHORT).show();
                    return;
                }

                double salario = Double.parseDouble(salarioStr);
                double novoSalario = salario;

                int checkedId = radioGroup.getCheckedRadioButtonId();
                if (checkedId == R.id.radio40) {
                    novoSalario = salario * 1.40;
                } else if (checkedId == R.id.radio45) {
                    novoSalario = salario * 1.45;
                } else if (checkedId == R.id.radio50) {
                    novoSalario = salario * 1.50;
                } else {
                    Toast.makeText(MainActivity.this, "Selecione o percentual de aumento!", Toast.LENGTH_SHORT).show();
                    return;
                }

                textResultado.setText(String.format("Novo salário: R$ %.2f", novoSalario));
            }
        });
    }
}